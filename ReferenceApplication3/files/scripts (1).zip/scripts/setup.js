let userGroupDescriptors = [
  {
    _name: "Solutions Mgmt",
    _shortName: "sol_man",
    _description: "Solutions User Group",
    permissions: {
      //accessAll is for easy creation of an admin with access to everything
      accessAll: true
    }
  },
  {
    _name: "Proj Admin",
    _shortName: "proj_admin",
    _description: "Proj Admin User Group",
    permissions: {
      //accessAll is for easy creation of an admin with access to everything
      accessAll: true
    }
  },

  {
    _name: "File Contributor",
    _shortName: "file_contrib",
    _description: "File Contributor User Group",
    permissions: {
      workspaces: [{ actions: ["READ", "EDIT"] }],
      namedUserItems: [{ actions: ["READ", "EDIT"] }],
      files: [{ actions: ["READ", "EDIT"] }]
    }
  },

  {
    _name: "Viewer",
    _shortName: "file_reviewer",
    _description: "File Reviewer User Group",
    permissions: {
      workspaces: [{ actions: ["READ"] }],
      namedUserItems: [{ actions: ["READ"] }],
      files: [{ actions: ["READ"] }]
    }
  }
];

let scriptsDescriptors = [
  {
    _name: "Load Project Collection Data",
    _shortName: "iaf_dt_proj_colls",
    _description: "Load All Project Collections",
    _userType: "iaf_dt_proj_colls"
  },

  {
    _name: "BIMPK Upload",
    _shortName: "iaf_bimpk_upload",
    _description: "Load, Transform and Write Model from BIMPK",
    _userType: "iaf_bimpk_upload"
  },

  {
    _name: "SGPK Upload",
    _shortName: "iaf_sgpk_upload",
    _description: "Load, Transform and Write Model from BIMPK",
    _userType: "iaf_sgpk_upload"
  },

  {
    _name: "BIMPK Post Import - Copy Inverse Relations",
    _shortName: "iaf_bimpk_post_imp",
    _description:
      "BIMPK Post Import - Copy Inverse Relations from Prev Version",
    _userType: "iaf_bimpk_post_imp"
  },
  {
    _name: "Re-mapping type elements",
    _shortName: "iaf_map_elms_type",
    _description: "Update model type elements, after BIMtypes updated",
    _userType: "iaf_map_elms_type"
  },
  {
    _name: "Model Reporting and Validation",
    _shortName: "iaf_ext_val_scr",
    _description: "Scripts to Inspect Model Content and Generate Reports",
    _userType: "iaf_ext_val_scr"
  },
  {
    _name: "Dashboard Scripts",
    _shortName: "iaf_dummy_dashboard",
    _description: "Scripts to provide data for dashboard development",
    _userType: "iaf_dummy_dashboard"
  },
  {
    _name: "Files As Entities All Users",
    _shortName: "iaf_files_allusers",
    _description: "Files for Entity View",
    _userType: "iaf_files_allusers"
  },
  {
    _name: "Files As Entities All Users",
    _shortName: "iaf_dt_model_elems",
    _description: "Model elements",
    _userType: "iaf_dt_model_elems"
  },

  {
    _name: "BMS Equipment Entity scripts",
    _shortName: "iaf_bms_allusers",
    _description: "BMS data as entities",
    _userType: "iaf_bms_allusers"
  },

  {
    _name: "Object Model API Scripts",
    _shortName: "iaf_obj_model_api",
    _description: "Object Model API Asset Script",
    _userType: "iaf_obj_model_api"
  },

  {
    _name: "Import Data Sheets",
    _shortName: "iaf_import_data_sheets",
    _description: "Import Data Sheets",
    _userType: "iaf_import_data_sheets"
  },

  {
    _name: "Orchestrator",
    _shortName: "orchestrator",
    _description: "Schedule orchestrator",
    _userType: "orchestrator"
  },

  {
    _name: "Entity Relations Scripts",
    _shortName: "iaf_relations_scripts",
    _description:
      "Scripts to manage (CRUD) parent-child relations between entities",
    _userType: "iaf_relations_scripts"
  },

  {
    _name: "Export Data Sheets",
    _shortName: "iaf_export_data_sheets",
    _description: "Export Data Sheets",
    _userType: "iaf_export_data_sheets"
  },

  {
    _name: "Schemas Scripts",
    _shortName: "iaf_schemas_allusers",
    _description: "Scripts to handle schemas",
    _userType: "iaf_schemas_allusers"
  },

  {
    _name: "Pick List Scripts",
    _shortName: "iaf_pick_lists",
    _description: "Scripts to work with pick lists",
    _userType: "iaf_pick_lists"
  },

  {
    _name: "System Scripts",
    _shortName: "iaf_systems_scripts",
    _description: "Scripts to work with systems",
    _userType: "iaf_systems_scripts"
  }
];

let userConfigDescriptors = [
  {
    _name: "DBM Contributor",
    _shortName: "iaf_dbm_contrib_uc",
    _description: "DBM Contributor User Config",
    _userType: "ipa-dt"
  },

  {
    _name: "DBM Viewer",
    _shortName: "iaf_dbm_review_uc",
    _description: "DBM Reviewer User Config",
    _userType: "ipa-dt"
  },

  {
    _name: "DBM Project Admin",
    _shortName: "iaf_dbm_projadmin_uc",
    _description: "DBM Project Admin User Config",
    _userType: "ipa-dt"
  }
];

// Map between UserConfig and UserGroups; kept separate to avoid using complex projections
let userConfigToUserGroupMap = [
  { userConfig: "iaf_dbm_contrib_uc", userGroup: "file_contrib" },
  { userConfig: "iaf_dbm_review_uc", userGroup: "file_reviewer" },
  { userConfig: "iaf_dbm_projadmin_uc", userGroup: "proj_admin" }
];

//each script is now a function
let RunnableScripts = [{ name: "Setup Project", script: "setUpProject" }];

let ProjSetup = {
  RunnableScripts: RunnableScripts,

  async setUpProject(PlatformApi, UiUtils, IafScriptEngine, scriptFile, ctx) {
    let zip = scriptFile[0];
    let configFiles = await UiUtils.IafLocalFile._loadZipFile(zip);
    const proj = await PlatformApi.IafProj.getCurrent(ctx);
    if (!ctx._namespaces) {
      ctx._namespaces = proj._namespaces;
    }

    try {
      const res = await PlatformApi.IafProj.addUserGroups(
        proj,
        userGroupDescriptors,
        ctx
      );
      console.log("Add User Groups Response", res);
    } catch (e) {
      console.log("Error In Adding User Groups ", e);
      throw e; //! supposed to preserve stack
    }

    let result = await PlatformApi.IafProj.getScriptsByProjectId(proj._id, ctx);
    if (result && _.size(result._list) > 0) {
      let scripts = result._list;
      scripts.forEach(async (s) => {
        let obj = await import(
          PlatformApi.IafItemSvc.getScriptContentUrl(s._id, ctx)
        );
        console.log(`Module Import ${s._name}`, obj);
      });
    }
    console.log("GetScriptsByProjectId Response", result);

    //* Getting User Groups
    let userGroups = await PlatformApi.IafProj.getUserGroups(proj, ctx);

    //#region Upload all JS scripts
    //* Loading All JS Script Files
    var uploadRunnableScripts = async () => {
      let scriptNames = [
        "iaf_dt_proj_colls",
        "iaf_bimpk_upload",
        "iaf_bimpk_post_imp",
        "iaf_map_elms_type",
        /* "iaf_dummy_dashboard", */
        "iaf_files_allusers",
        "iaf_dt_model_elems",
        "iaf_obj_model_api",
        "iaf_import_data_sheets",
        "orchestrator"
        /* "iaf_relations_scripts" */
      ];
      var iaf_dt_proj_colls = await configFiles.files[
        "scripts/NextScriptEngine/scripts/js/iaf_dt_proj_colls.js"
      ].async("string");
      var iaf_bimpk_upload = await configFiles.files[
        "scripts/NextScriptEngine/scripts/js/iaf_bimpk_upload.js"
      ].async("string");
      var iaf_bimpk_post_imp = await configFiles.files[
        "scripts/NextScriptEngine/scripts/js/iaf_bimpk_post_imp.js"
      ].async("string");
      var iaf_map_elms_type = await configFiles.files[
        "scripts/NextScriptEngine/scripts/js/iaf_map_elms_type.js"
      ].async("string");
      /* var iaf_dummy_dashboard = await configFiles.files[
        "scripts/NextScriptEngine/scripts/js/iaf_dummy_dashboard.js"
      ].async("string"); */
      var iaf_files_allusers = await configFiles.files[
        "scripts/NextScriptEngine/scripts/js/iaf_files_allusers.js"
      ].async("string");
      var iaf_dt_model_elems = await configFiles.files[
        "scripts/NextScriptEngine/scripts/js/iaf_dt_model_elems.js"
      ].async("string");
      var iaf_obj_model_api = await configFiles.files[
        "scripts/NextScriptEngine/scripts/js/iaf_obj_model_api.js"
      ].async("string");
      var iaf_import_data_sheets = await configFiles.files[
        "scripts/NextScriptEngine/scripts/js/iaf_import_data_sheets.js"
      ].async("string");
      var orchestrator = await configFiles.files[
        "scripts/NextScriptEngine/scripts/js/orchestrator.js"
      ].async("string");
      /* var iaf_relations_scripts = await configFiles.files[
        "scripts/NextScriptEngine/scripts/js/iaf_relations_scripts.js"
      ].async("string"); */
      let scriptContents = [
        iaf_dt_proj_colls,
        iaf_bimpk_upload,
        iaf_bimpk_post_imp,
        iaf_map_elms_type,
        /* iaf_dummy_dashboard, */
        iaf_files_allusers,
        iaf_dt_model_elems,
        iaf_obj_model_api,
        iaf_import_data_sheets,
        orchestrator
        /* iaf_relations_scripts */
      ];
      let scripts = _.zip(scriptNames, scriptContents);
      let scriptDefs = _.map(scripts, (s) => {
        return { scriptName: s[0], scriptContent: s[1] };
      });
      let scriptItems = [];
      scriptDefs.forEach((c) => {
        let item = _.find(scriptsDescriptors, { _shortName: c.scriptName });
        if (item) {
          //TODO: use javascript stringify, not JSON stringify
          item._version = { _userData: c.scriptContent };
          item._namespaces = proj._namespaces;
          scriptItems.push(item);
        }
      });
      //TODO: create scripts
      let createScriptRes = await PlatformApi.IafScripts.create(
        scriptItems,
        ctx
      );
      console.log("CreateScript Response", createScriptRes);
    };
    //#endregion

    //#region Reading EXP files
    var userConifgImports = async () => {
      //* User Config Import
      let configNames = [
        "iaf_dbm_contrib_uc",
        "iaf_dbm_review_uc",
        "iaf_dbm_projadmin_uc"
      ];
      let ExpFile = new Array(3);
      let iaf_dbm_contrib_uc =
        "scripts/NextScriptEngine/userconfigs/iaf_dbm_contrib_uc.exp";
      let iaf_dbm_review_uc =
        "scripts/NextScriptEngine/userconfigs/iaf_dbm_review_uc.exp";
      let iaf_dbm_projadmin_uc =
        "scripts/NextScriptEngine/userconfigs/iaf_dbm_projadmin_uc.exp";

      await configFiles.files[
        "scripts/NextScriptEngine/userconfigs/iaf_dbm_contrib_uc.exp"
      ]
        .async("blob")
        .then(async (fileData) => {
          const selectFile = new File([fileData], iaf_dbm_contrib_uc);
          ExpFile[0] = {
            fileObj: selectFile,
            size: selectFile.size,
            name: selectFile.name
          };
        });
      await configFiles.files[
        "scripts/NextScriptEngine/userconfigs/iaf_dbm_review_uc.exp"
      ]
        .async("blob")
        .then(async (fileData) => {
          const selectFile = new File([fileData], iaf_dbm_review_uc);
          ExpFile[1] = {
            fileObj: selectFile,
            size: selectFile.size,
            name: selectFile.name
          };
        });
      await configFiles.files[
        "scripts/NextScriptEngine/userconfigs/iaf_dbm_projadmin_uc.exp"
      ]
        .async("blob")
        .then(async (fileData) => {
          const selectFile = new File([fileData], iaf_dbm_projadmin_uc);
          ExpFile[2] = {
            fileObj: selectFile,
            size: selectFile.size,
            name: selectFile.name
          };
        });

      let configContents = await UiUtils.IafLocalFile.loadEXPFiles(ExpFile);
      let configs = _.zip(configNames, configContents);
      let configDefs = _.map(configs, (c) => {
        return { configName: c[0], configContent: c[1] };
      });

      //create configItems
      let configItems = [];
      configDefs.forEach((c) => {
        let item = _.find(userConfigDescriptors, { _shortName: c.configName });
        if (item) {
          item._version = {
            _userData: JSON.stringify(c.configContent, null, 2)
          };
          configItems.push(item);
        }
      });

      //Look up the UserGroup mapped to each UserConfig
      let groupItems = [];
      configDefs.forEach((c) => {
        let group = _.find(userConfigToUserGroupMap, {
          userConfig: c.configName
        });
        let item = _.find(userGroups, { _shortName: group.userGroup });
        if (item) {
          groupItems.push(item);
        }
      });
      let configsAndGroups = _.zip(configItems, groupItems);
      let configsAndGroupDefs = _.map(configsAndGroups, (c) => {
        return { userConfig: c[0], userGroup: c[1] };
      });

      //createUserConfigsOnUserGroups
      configsAndGroupDefs.forEach(async (c) => {
        const result = await PlatformApi.IafUserGroup.addUserConfigs(
          c.userGroup,
          [c.userConfig],
          ctx
        );
        console.log(
          `AddUserConfigs Response: ${c.userConfig._name} ${c.userGroup._name}`,
          result
        );
      });
    };
    //#endregion

    //#region Add BIMPK Datasource
    var CreateBIMPKDatasource = async () => {
      let iaf_dt_grid_as_objects = [
        {
          "Revit Category": "OST_BuildingPad",
          "Revit Family": "Pad",
          "Revit Type": "A-M_Pad 1"
        },
        {
          "Revit Category": "OST_CableTray",
          baType: "Cable Trays",
          "Revit Family": "Cable Tray with Fittings",
          "Revit Type": "Submains Cable ladder",
          dtCategory: "Cable Tray",
          dtType: "Submains Cable ladder"
        },
        {
          "Revit Category": "OST_CableTray",
          baType: "Cable Trays",
          "Revit Family": "Cable Tray with Fittings",
          "Revit Type": "Channel Cable Tray",
          dtCategory: "Cable Tray",
          dtType: "Channel"
        }
      ];
      let atm_defs_coll = await IafScriptEngine.createOrRecreateCollection(
        {
          _name: "ATM Def Collection",
          _shortName: "typemap_defs",
          _namespaces: proj._namespaces,
          _description: "Asset Type Map Collection",
          _userType: "iaf_dt_type_map_defs_coll"
        },
        ctx
      );
      console.log("Collection Create Response", atm_defs_coll);

      let atm_defs_items_res = await IafScriptEngine.createItemsBulk(
        {
          _userItemId: atm_defs_coll._userItemId,
          _namespaces: proj._namespaces,
          items: iaf_dt_grid_as_objects
        },
        ctx
      );
      console.log("CreateItemsBulk Response", atm_defs_items_res);

      let datasourceResult = await IafScriptEngine.addDatasource(
        {
          _name: "BIMPK Uploader",
          _description: "Orchestrator to upload model from BIMPK file",
          _namespaces: proj._namespaces,
          _userType: "bimpk_uploader",
          _params: {
            tasks: [
              {
                name: "folder_cleaner_target",
                _sequenceno: 5
              },
              {
                name: "scz_relations_target",
                _sequenceno: 4
              },
              {
                name: "default_script_target",
                _actualparams: {
                  userType: "iaf_bimpk_upload",
                  // Possible values are ALL, SYSTEM_EQUIPMENTS, SPACIAL_STRUCTURE, SYSTEM_CONNECTIONS, ELECTRICAL_DEVICES, ELECTRICAL_CIRCUITS
                  // "sysRelationships": ["ALL"]
                  _scriptName: "uploadBimpk"
                },
                _sequenceno: 3
              },
              {
                name: "bimpk_element_extractor",
                _sequenceno: 2
              },
              {
                name: "bimpk_file_extractor",
                _sequenceno: 1
              }
            ]
          }
        },
        ctx
      );
      console.log("AddDatasource Response", datasourceResult);
    };
    //#endregion

    //#region BIMPK Model Upload and import
    var bimpkUploadAndImport = async () => {
      let iaf_bimpk_name = "1801KS-INV-01-ZZ-M3-Z-0001_Federated (1).bimpk";

      var createTelementaryCollection = async () => {
        // Named Telementary Collection
        const telementaryCollection =
          await PlatformApi.IafItemSvc.createNamedUserItems(
            [
              {
                _name: "Named Telemetry Collection",
                _shortName: "telementary_coll",
                _description:
                  "Named Telemetry Collection to store sensor and points data",
                _namespaces: proj._namespaces,
                _userType: "ref_app_telementary_collection"
              }
            ],
            "NamedTelemetryCollection",
            ctx
          );
        console.log("telementaryCollection", telementaryCollection);
        var TelemetryCollectionRelations = async () => {
          // Sensor data to relate with collection
          let relatedItems = [
            {
              floorname: "2nd Floor",
              roomname: "Lab",
              _sourceId: "e3e052f9-0156-11d5-9301-0000863f27ad-00000131"
            }
          ];
          let telementryRelatedItems =
            await PlatformApi.IafItemSvc.createRelatedItems(
              telementaryCollection._list[0]._id,
              relatedItems,
              ctx
            );
          let ctx1 = ctx._namespaces[0];
          // Pump Element Id
          /* let url = await PlatformApi.IafFetch.constructUrl(
            "https://ncircle-dev.invicara.com/omapi",
            ctx1,
            'model?query={"properties.Revit Family.val":{"$in":["F-M_Jockey Pump"]}}'
          );
          const pumpId = await PlatformApi.IafFetch.doGet(url, ctx, undefined);
          console.log("pumpId", pumpId);
          console.log("id", pumpId._result[0]._id); */
          let relationShips = [
            {
              _relatedFromId: "638d8ec3b3e666c133bf298c", // parent id
              _relatedToIds: telementryRelatedItems._list.map(
                (item) => item._id
              ), // children from tip version
              _relatedUserItemDbId: telementaryCollection._list[0]._id
            }
          ];
          // To create relation between pump element id,sensor data and collection
          let relations = await PlatformApi.IafItemSvc.addRelations(
            telementaryCollection._list[0]._id,
            relationShips,
            ctx
          );
          console.log("relations", relations);
        };
        await TelemetryCollectionRelations();
      };

      var createIndex = async () => {
        let compositeCollection = await IafScriptEngine.getCompositeCollection(
          {
            query: {
              _userType: "bim_model_version",
              _namespaces: {
                $in: proj._namespaces
              },
              _itemClass: "NamedCompositeItem"
            }
          },
          ctx,
          { getLatestVersion: true }
        );
        let _userItemId = compositeCollection._userItemId;

        let collectionInComposite =
          await IafScriptEngine.getCollectionInComposite(_userItemId, {
            _userType: "rvt_type_elements"
          });

        // revit
        let indexRes = await IafScriptEngine.createOrRecreateIndex(
          {
            // model type elememt colletcion
            _id: collectionInComposite._userItemId,
            indexDefs: [
              {
                key: {
                  "Revit Category": 1
                },
                options: {
                  name: "model_els_coll_id",
                  default_language: "english"
                }
              }
            ]
          },
          ctx
        );

        document.getElementById("donebtn").style.display = "block";
        document.getElementById("msg").innerHTML = "Project Setup Completed";
      };
      var fetchOSTDoors = async () => {
        let project = await PlatformApi.IafProj.getCurrent();
        let context;

        context = { _namespaces: project._namespaces };
        let latestModelComposite = await IafScriptEngine.getCompositeCollection(
          {
            query: {
              _userType: "bim_model_version",
              _namespaces: { $in: project._namespaces },
              _itemClass: "NamedCompositeItem"
            }
          },
          context,
          { getLatestVersion: true }
        );
        const latestElementCollection =
          await IafScriptEngine.getCollectionInComposite(
            latestModelComposite._id,
            { _userType: "rvt_elements" },
            context
          );
        let bimQuery = {
          parent: {
            collectionDesc: {
              _userType: "rvt_elements",
              _userItemId: latestElementCollection._userItemId
            },
            options: {
              page: {
                getAllItems: true
              }
            },
            sort: {
              _id: 1
            }
          },
          related: [
            {
              relatedDesc: {
                _relatedUserType: "rvt_type_elements"
              },
              as: "Revit Type Properties"
            },
            {
              relatedDesc: {
                _relatedUserType: "rvt_element_props"
              },
              as: "Revit Element Properties"
            }
          ],
          relatedFilter: {
            $and: [
              {
                relatedDesc: {
                  _relatedUserType: "rvt_type_elements"
                },
                as: "Revit Type Properties",
                query: {
                  "properties.Revit Category.val": { $in: ["OST_Doors"] }
                }
              }
            ]
          }
        };
        let elements = await IafScriptEngine.findWithRelated(bimQuery, context);
        let entities = elements._list.map((e) => {
          let properties = {};

          Object.keys(e["Revit Type Properties"]._list[0].properties).forEach(
            (key) => {
              let currentProp =
                e["Revit Type Properties"]._list[0].properties[key];
              properties[key] = {
                dName: currentProp.dName,
                val: currentProp.val
                  ? currentProp.val
                  : "" + " " + currentProp.uom
                  ? currentProp.uom
                  : "",
                type: "text"
              };
            }
          );

          Object.keys(
            e["Revit Element Properties"]._list[0].properties
          ).forEach((key) => {
            let currentProp =
              e["Revit Element Properties"]._list[0].properties[key];
            properties[key] = {
              dName: currentProp.dName,
              val: currentProp.val
                ? currentProp.val
                : "" + " " + currentProp.uom
                ? currentProp.uom
                : "",
              type: "text"
            };
          });

          let revitFamily = e["Revit Type Properties"]._list[0].properties[
            "Revit Family"
          ]
            ? e["Revit Type Properties"]._list[0].properties["Revit Family"].val
            : "No Family";
          let revitType = e["Revit Type Properties"]._list[0].properties[
            "Revit Type"
          ]
            ? e["Revit Type Properties"]._list[0].properties["Revit Type"].val
            : "No Type";
          let sysElemId =
            e["Revit Element Properties"]._list[0].properties.SystemelementId
              .val;
          return {
            _id: e._id,
            "Entity Name": revitFamily + "-" + revitType + "-" + sysElemId,
            properties,
            modelViewerIds: [e.package_id]
          };
        });
        return entities;
      };
      var createWarrantyAndElementRelation = async () => {
        let Coll_info = {
          Name: "Element Warranty Data",
          ShortName: "war_data",
          Description: "Element Warranty Data",
          userType: "iaf_dt_warranty_coll"
        };

        let iaf_ext_current_bim_model =
          await PlatformApi.IafScriptEngine.getCompositeCollection(
            {
              query: {
                _userType: "bim_model_version",
                _namespaces: { $in: proj._namespaces },
                _itemClass: "NamedCompositeItem"
              }
            },
            ctx,
            { getLatestVersion: true }
          );
        console.log("iaf_ext_current_bim_model", iaf_ext_current_bim_model);
        let rvt_coll =
          await PlatformApi.IafScriptEngine.getCollectionInComposite(
            iaf_ext_current_bim_model._userItemId,
            { _userType: "rvt_elements" },
            ctx
          );
        // Reference BIM Query
        let doors = await fetchOSTDoors();
        console.log("OST_Doors", doors);
        let revit_elements = doors;

        console.log("revit_elements", revit_elements);
        let dataObject = {
          properties: {
            "Warranty Description": {
              dName: "Warranty Description",
              val: "The manufacturer warrants this product to be free from defects in workmanship and materials, under normal residential use and conditions, for a period of one (1) year for the original invoice date",
              type: "text",
              epoch: null
            },
            "Warranty Starte Date": {
              dName: "Warranty Starte Date",
              val: "09-11-2022",
              type: "date"
            },
            "Warranty Duration": {
              dName: "Warranty Duration",
              val: "1 year",
              type: "text"
            }
          }
        };

        let flatAllDataObjs = [];

        for (let i = 0; i < revit_elements.length; i++) {
          flatAllDataObjs.push(dataObject);
        }
        let data_obj_coll =
          await PlatformApi.IafScriptEngine.createOrRecreateCollection(
            {
              _name: Coll_info.Name,
              _shortName: Coll_info.ShortName,
              _namespaces: proj._namespaces,
              _description: Coll_info.Description,
              _userType: Coll_info.userType
            },
            ctx
          );
        console.log("data_obj_coll", data_obj_coll);
        let data_obj_res = await PlatformApi.IafScriptEngine.createItemsBulk(
          {
            _userItemId: data_obj_coll._userItemId,
            _namespaces: proj._namespaces,
            items: flatAllDataObjs
          },
          ctx
        );
        console.log("data_obj_res", data_obj_res);
        //CREATE ITEMS BULK DOESNT RETURN THE CREATED OBJECTS
        //IT RETURNS URIS FOR THE OBJECTS
        //SO GET ALL THOSE IN ONE LIST WHICH WE WILL USE
        //TO GET THE NEW OBJECT IDS OFF THE END
        const allURIs = _.flatten(_.map(data_obj_res[0], (d) => d._uris));
        console.log("allURIs", allURIs);
        const dataObjIds = _.map(allURIs, (u) => _.last(_.split(u, "/")));
        console.log("dataObjIds", dataObjIds);
        //ZIP THE NEW DATA IDS WITH THE ASSETS
        //THIS SHOULD BE IN THE CORRECT ORDER
        const assetsWithDataIds = _.zip(revit_elements, dataObjIds);
        console.log("assetsWithDataIds", assetsWithDataIds);
        //CREATE RELATIONS
        const relatedItems = _.map(assetsWithDataIds, (d) => {
          return {
            parentItem: d[0],
            relatedItems: [{ _id: d[1] }]
          };
        });
        console.log("relatedItems", relatedItems);
        debugger;
        const relations = await PlatformApi.IafScriptEngine.createRelations(
          {
            parentUserItemId: rvt_coll._userItemId,
            _userItemId: data_obj_coll._userItemId,
            _namespaces: proj._namespaces,
            relations: relatedItems
          },
          ctx
        );
        console.log("relations", relations);
        //GET AN ASSET WITH THE RELATED DATA AS A TEST
        const testAsset = await PlatformApi.IafScriptEngine.findWithRelated(
          {
            parent: {
              query: { _id: revit_elements[0]._id },
              collectionDesc: { _userItemId: rvt_coll._userItemId },
              options: { page: { getAllItems: true } }
            },
            related: [
              {
                relatedDesc: { _relatedUserType: data_obj_coll._userType },
                as: "Related Data Object"
              }
            ]
          },
          ctx
        );
        console.log("Extended Collection : ", data_obj_coll);
        console.log("testAsset for Warranty Collection : ", testAsset._list[0]);
        return {
          extendedDataCollection: data_obj_coll,
          testAsset: testAsset._list[0]
        };
      };
      //* BIMPK file upload progress
      var onProgress = async (bytesUploaded, bytesTotal) => {
        let percentage = ((bytesUploaded / bytesTotal) * 100).toFixed(2);
        document.getElementById("msg2").innerHTML = percentage + "%";
        console.log(
          iaf_bimpk_name,
          bytesUploaded,
          bytesTotal,
          percentage + "%"
        );
      };

      //* BIMPK file upload success Callback
      var onSuccess = async () => {
        document.getElementById("msg2").innerHTML = "";
        // let rootContainer = await IafFile.createContainer({_namespaces: project._namespaces}, undefined, ctx);
        let criteria = { _name: ".*bimpk" };
        let fileItem = await PlatformApi.IafFileSvc.getFiles(criteria, ctx);
        let file_id = fileItem._list[0]._id;
        let fileVersion = await PlatformApi.IafFile.getFileVerisons(
          file_id,
          ctx
        );
        // run orch
        const query = {
          _namespaces: proj._namespaces,
          _userType: "bimpk_uploader"
        };

        const datasources = await IafScriptEngine.getDatasources(query, ctx);

        console.log("BIMPK datasources", JSON.stringify(datasources));
        let dtSisenseOrch = _.filter(
          datasources,
          (d) =>
            d._userType === "bimpk_uploader" && d._name === "BIMPK Uploader"
        );
        console.log("BIMPK dtSisenseOrch", JSON.stringify(dtSisenseOrch));

        // getFileVersion id from fileid
        const orchReq = {
          orchestratorId: dtSisenseOrch[0].id,
          _actualparams: [
            {
              sequence_type_id: "9a616686-571e-4167-8a70-d180dcd585a9",
              params: {
                //replace file id and verid with actual file and version id
                _fileId: fileItem._list[0]._id,
                _fileVersionId: fileVersion._list[0]._id
              }
            }
          ]
        };
        console.log("ORCH Request Body", JSON.stringify(orchReq));

        const orchRes = await IafScriptEngine.runDatasource(orchReq, ctx);
        console.log("ORCH Response Data", JSON.stringify(orchRes));

        const orchReqForRes = { runid: orchRes.id };
        let status = await IafScriptEngine.getDatasourceRunStatus(
          orchReqForRes
        );
        var timer = setInterval(async () => {
          status = await IafScriptEngine.getDatasourceRunStatus(orchReqForRes);
          console.log("Datasource Run Status", status[0]);
          if (status[0]._status == "COMPLETED") {
            clearInterval(timer);
            //* Creates indexing for Search
            await createIndex();
            //* Creates Telementary Collection
            await createTelementaryCollection();
            //* Creates relation between warranty data and model elements
            await createWarrantyAndElementRelation();
          }
        }, 10000);
      };

      //* BIMPK file upload
      await configFiles.files[`scripts/${iaf_bimpk_name}`]
        .async("blob")
        .then(async (fileData) => {
          const selectedFile = new File([fileData], iaf_bimpk_name);
          var file = {
            fileObj: selectedFile,
            size: selectedFile.size,
            name: selectedFile.name
          };
          let uploadedFile = await IafScriptEngine.uploadFile(
            file,
            ctx,
            onProgress,
            onSuccess
          );
          console.log("BIMPK Upload File Response", uploadedFile);
        });
    };
    //#endregion

    //#region File Attributes Import
    var fileAttributesImport = async () => {
      const fileAttributesFile = "scripts/xslx/Kingspan_FileAttributes.xlsx";
      const data = await configFiles.files[fileAttributesFile].async("blob");
      let proj = await PlatformApi.IafProj.getCurrent();
      var fileObj = new File([data], "FileAttributes.xlsx");
      console.log("Importing File Attributes.", fileObj);
      var xlsxFiles = new Array({
        name: "FileAttributes.xlsx",
        size: fileObj.size,
        fileObj
      });
      let typeWorkbook = await UiUtils.IafDataPlugin.readXLSXFiles(xlsxFiles);
      let wbJSON = UiUtils.IafDataPlugin.workbookToJSON(typeWorkbook[0]);
      console.log("Reading Attributes Completed.", wbJSON);
      let iaf_dt_grid_data = wbJSON["Document Attributes"];
      let iaf_dt_grid_as_objects = UiUtils.IafDataPlugin.parseGridData({
        gridData: iaf_dt_grid_data,
        options: { asColumns: true }
      });
      let file_attrib_coll = await IafScriptEngine.createOrRecreateCollection(
        {
          _name: "FDM File Attrib Collection",
          _shortName: "rkfileattrib",
          _namespaces: proj._namespaces,
          _description: "FDM File Attribute Collection",
          _userType: "iaf_cde_file_attrib_coll"
        },
        ctx
      );
      console.log(
        "FileAttributes CreateOrRecreateCollection Response",
        file_attrib_coll
      );
      let fileAttributes = [
        {
          originator: iaf_dt_grid_as_objects["Originator"],
          contributor: iaf_dt_grid_as_objects["Contributor"],
          building: iaf_dt_grid_as_objects["Building"],
          levelsAndLocations: iaf_dt_grid_as_objects["Levels And Locations"],
          documentType: iaf_dt_grid_as_objects["Document Type"],
          fileDiscipline: iaf_dt_grid_as_objects["File Discipline"],
          manufacturer: iaf_dt_grid_as_objects["Manufacturer"],
          fileType: iaf_dt_grid_as_objects["File Type"],
          revision: iaf_dt_grid_as_objects["Revision"],
          stageDescription: iaf_dt_grid_as_objects["Stage Description"]
        }
      ];
      let file_attribs = await IafScriptEngine.createItems(
        {
          _userItemId: file_attrib_coll._userItemId,
          _namespaces: proj._namespaces,
          items: fileAttributes
        },
        ctx
      );
      console.log("FileAttributes CreateItems Response", file_attribs);

      console.log("Creating Root Container...");
      let resCont = await PlatformApi.IafFile.createContainer(
        proj,
        undefined,
        ctx
      );
      console.log("Root Container Created Response", resCont);

      let root_file_cont = await IafScriptEngine.getFileCollection(
        {
          _userType: "file_container",
          _shortName: "Root Container"
        },
        ctx
      );

      console.log("FileAttributes Get FileCollection Response", root_file_cont);
      const res = await IafScriptEngine.createOrRecreateIndex(
        {
          _id: root_file_cont._id,
          indexDefs: [
            {
              key: {
                name: "text",
                "fileAttributes.documentType": "text",
                "fileAttributes.originator": "text",
                "fileAttributes.dtCategory": "text",
                "fileAttributes.dtType": "text"
              },
              options: {
                name: "text_search_index",
                default_language: "english"
              }
            }
          ]
        },
        ctx
      );
      console.log("FileAttributes Create Index Response", res);
    };
    //#endregion

    //#region Add Api Gateway Config
    var apiConfigImport = async () => {
      let apiConfig =
        "scripts/NextScriptEngine/ObjectModelAPIConfig/apiconfig.json";
      const data = await configFiles.files[apiConfig].async("blob");
      var fileObj = new File([data], "apiconfig.json");
      const configFile = new Array({
        name: "apiconfig.json",
        size: fileObj.size,
        fileObj: fileObj
      });
      const configFileData = await UiUtils.IafLocalFile.loadFiles(configFile);
      const configData = [JSON.parse(configFileData[0])];
      console.log("API Config Data", configData);
      const configFileItem = await PlatformApi.IafItemSvc.createNamedUserItems(
        [
          {
            _name: "API config",
            _shortName: "api_config",
            _description: "API configuration with the REST API endpoints",
            _namespaces: proj._namespaces,
            _userType: "api_config",
            _version: { _userData: JSON.stringify(configData) }
          }
        ],
        "UserConfig",
        ctx
      );
      const configFileItemId =
        configFileItem &&
        configFileItem._list &&
        configFileItem._list[0] &&
        configFileItem._list[0]._id
          ? configFileItem._list[0]._id
          : undefined;
      if (configFileItemId) {
        const addApiConfigResponse =
          await PlatformApi.IafObjectModelAPISvc.addApiConfig(
            configFileItemId,
            ctx
          );
        console.log("AddApiConfig Response", addApiConfigResponse);
        console.log("ApiConfig imported successfully");
      } else {
        console.log("Failed to add apiConfig");
      }
    };
    //#endregion

    //#region All Tasks Entries

    //* Create Scripts
    await uploadRunnableScripts();

    //* User Configs Import
    await userConifgImports();

    //* Create BIMPKDatasource
    await CreateBIMPKDatasource();

    // //* bimpk upload and import
    await bimpkUploadAndImport();

    //* files attributes import
    // await fileAttributesImport();

    //* add api gateway config
    await apiConfigImport();

    //#endregion
  },

  getRunnableScripts() {
    return RunnableScripts;
  }
};

export default ProjSetup;
//window.inv_user = ProjSetup
