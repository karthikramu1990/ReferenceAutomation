export default {
    async telemetryTemperature(params, libraries, ctx) {
        let param = params.inparams;
        let readings =  [
            {
                "Temperature": Math.floor(Math.random() * (50 - 1 + 1)) + 1,
                "_ts":"2022-11-18T05:15:30+05:30",
                "_tsMetadata": {
                    "_telItemId": params.actualParams.RelatedItemId,
                    "_sourceId": params.actualParams.sensorId
                }
            }
        ];
    let ReadingItems1 = await libraries.PlatformApi.IafItemSvc.createRelatedReadingItems(params.actualParams.TelemetryCollectionId,readings, ctx);
    }
}
