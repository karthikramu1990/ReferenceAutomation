const isEmpty = (ele) => {
    if(ele === undefined){
        return true;
    } else if (ele === null) {
        return true;
    }
    return false;
}

const getElements = async (input, IafScriptEngine, context) => {
    let latestModelComposite = await IafScriptEngine.getCompositeCollection({
        query:
        {
            "_userType": "bim_model_version",
            "_namespaces": { "$in": context._namespaces },
            "_itemClass": "NamedCompositeItem"
        }
    }, context, { getLatestVersion: true })
    const latestElementCollection = await IafScriptEngine.getCollectionInComposite(latestModelComposite._id,
        { _userType: "rvt_elements" }, context);
    let bimQuery = {
        "parent": {
            "collectionDesc": {
                "_userType": "rvt_elements",
                "_userItemId": latestElementCollection._userItemId
            },
            "options": {
                "page": {
                    "getAllItems": true
                }
            },
            "sort": {
                "_id": 1
            }
        },
        "related": [
            {
                "relatedDesc": {
                    "_relatedUserType": "rvt_type_elements"
                },
                "as": "Revit Type Properties"
            },
            {
                "relatedDesc": {
                    "_relatedUserType": "rvt_element_props"
                },
                "as": "Revit Element Properties"
            }
        ],
        "relatedFilter": {
            "$and": [
                {
                    "relatedDesc": {
                        "_relatedUserType": "rvt_type_elements"
                    },
                    "as": "Revit Type Properties",
                    "query": input.params.query
                }
            ]
        }
    };

    let elements = await IafScriptEngine.findWithRelated(bimQuery, context)
    let entities = elements._list.map(e => {
        let properties = {}
        if (!isEmpty(e["Revit Type Properties"]._list[0])) {
            Object.keys(e["Revit Type Properties"]._list[0].properties).forEach((key) => {
                let currentProp = e["Revit Type Properties"]._list[0].properties[key]
                properties[key] = {
                    dName: currentProp.dName,
                    val: currentProp.val ? currentProp.val : "" + " " + currentProp.uom ? currentProp.uom : "",
                    type: "text"
                }
            })
        }
        if (!isEmpty(e["Revit Element Properties"]._list[0])) {
            Object.keys(e["Revit Element Properties"]._list[0].properties).forEach((key) => {
                let currentProp = e["Revit Element Properties"]._list[0].properties[key]
                properties[key] = {
                    dName: currentProp.dName,
                    val: currentProp.val ? currentProp.val : "" + " " + currentProp.uom ? currentProp.uom : "",
                    type: "text"
                }
            })
        }
        let revitFamily = e["Revit Type Properties"]._list[0].properties["Revit Family"] ? e["Revit Type Properties"]._list[0].properties["Revit Family"].val : "No Family"
        let revitType = e["Revit Type Properties"]._list[0].properties["Revit Type"] ? e["Revit Type Properties"]._list[0].properties["Revit Type"].val : "No Type"
        let sysElemId = e["Revit Element Properties"]._list[0].properties.SystemelementId.val
        return {
            _id: e._id,
            "Entity Name": revitFamily + "-" + revitType + "-" + sysElemId,
            properties,
            modelViewerIds: [e.package_id]
        }
    })
    return entities
}

const getRelatedFilesContainer = async (project, P_API, context) => {
    let containers = await P_API.IafFile.getContainers(project, { _name : "Related Files" }, context);
    if(containers === null){
        let containerInfo = {
            _name: "Related Files",
            _description: "Folder to store related files for model elements.",
            _shortName: "related_files",
            _userType: "model_docs",
        };
        let rootContainer = await P_API.IafFile.getRootContainer(project, context);
        if(isEmpty(rootContainer)){
            rootContainer = await P_API.IafFile.createContainer({ _namespaces: project._namespaces }, undefined, context);
        }
        let newContainer = await P_API.IafFile.createContainer(rootContainer, containerInfo, context);
        return newContainer;
    }
    return containers[0];
}

export default {
    async getModelElements(input, libraries, context) {
        const IafScriptEngine = libraries.PlatformApi.IafScriptEngine;
        try {
            const P_API = libraries.PlatformApi;
            let project = await P_API.IafProj.getCurrent();
            if(!context) {
                context = {_namespaces :  project._namespaces };
            }
            const dog = await getElements(input, IafScriptEngine, context);
            console.log(dog);
            return dog;
        } catch (error) {
            console.log(error);
            return { error: JSON.stringify(error) }
        }
    },

    async getRelatedFileItemsForModelElements(input, libraries, context) {
        try { 
            const P_API = libraries.PlatformApi;
            let project = await P_API.IafProj.getCurrent();
            if(!context) {
                context = {_namespaces :  project._namespaces };
            }
            const container = await getRelatedFilesContainer(project, P_API, context);
            const items = await P_API.IafItemSvc.getRelations(container._id,
                {
                    query: { _relatedFromId: input.entityInfo._id },
                    options: { page: { getAllItems: true } }
                }, context);
            const result = [];
            for (let i = 0; i < items._list.length; i++) {
                const file = items._list[i];
                for (let j = 0; j < file._relatedToIds.length; j++) {
                    const fileId = file._relatedToIds[j];
                    const x = await P_API.IafFile.getFileItem(container, {_id : fileId}, context);
                    const user = await P_API.IafPassSvc.getUserById(x._metadata._updatedById, context)
                    result.push({
                        name: x.name,
                        updatedAt: new Date(x._metadata._updatedAt).toDateString(),
                        updatedBy: `${user._firstname} ${user._lastname}`,
                        size : x._uploadMeta !== undefined ? x._uploadMeta._size : 0,
                        fileId: fileId,
                        id: x._fileId
                    });
                }
            }
            return result;
        } catch (error) {
            console.log(error);
            return "Error";
        }
    },

    async uploadRelatedFileItem(input, libraries, context) {
        try {
            if(Array.isArray(input.entityInfo.new) && input.entityInfo.new.length === 0){
                return;
            }
            const P_API = libraries.PlatformApi;
            let project = await P_API.IafProj.getCurrent();
            if(!context) {
                context = {_namespaces :  project._namespaces };
            }
            const configFile = await libraries.UiUtils.IafLocalFile.selectFiles({multiple: false});
            if(configFile.length > 0 ){
                const container = await getRelatedFilesContainer(project, P_API, context);
                const file = await P_API.IafFile.uploadFile(container, configFile[0].fileObj, ["related"], context);
                const relationShips = [{
                    "_relatedFromId" : input.entityInfo.new._id,
                    "_relatedToIds" : [file._id],
                    "_relatedUserItemDbId" : container._id
                }];
                await P_API.IafItemSvc.addRelations(container._id ,relationShips, context)
            }
        } catch (error) {
            console.log(error);
        }
    },

    async deleteRelatedItem(input, libraries, context) {
        try {
            const fileId = input.query.data.fileId;
            const P_API = libraries.PlatformApi;
            let project = await P_API.IafProj.getCurrent();
            if(!context) {
                context = {_namespaces :  project._namespaces };
            }
            const container = await getRelatedFilesContainer(project, P_API, context);
            const items = await P_API.IafItemSvc.getRelations(container._id, 
                { "_relatedToIds" : [fileId] }, context);
            const relation = items._list[0];
            relation._relatedToIds = [fileId];
            await P_API.IafItemSvc.deleteRelations(container._id, [relation], context)
        } catch (error) {
            console.log(error);
        }
    },
    async getTelemetryCollection(input, libraries, context) {
        try {
            const IafItemSvc = libraries.PlatformApi.IafItemSvc;
            let query = {"_usertype":"ref_app_telementary_collection","_name":"Named Telemetry Collection"}
            let itemId = await IafItemSvc.getNamedUserItems(query,context,undefined);
            let refAppTelemetryCollection=""
            for(const ele of itemId._list){
              if (ele._userType=='ref_app_telementary_collection'){
                refAppTelemetryCollection =ele._id
              } 
            }
            let relatedItem = await IafItemSvc.getRelations(refAppTelemetryCollection,{
                "_relatedFromId" : input.entityInfo._id
            }, context);
            let collectionId = refAppTelemetryCollection
            let selectedElementId = input.entityInfo._id
            return ({collectionId,selectedElementId});
        } catch (error) {
            return { error: JSON.stringify(error) }

        }
      }
}